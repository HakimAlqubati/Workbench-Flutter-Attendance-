class AppRoutes {
  static const faceLiveness = '/face-liveness';
  static const login = '/login';
  static const settings = '/settings';
  static const attendanceKeypad = '/attendance-keypad';
}
